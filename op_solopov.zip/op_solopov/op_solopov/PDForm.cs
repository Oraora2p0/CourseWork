﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Data.SQLite;

namespace op_solopov
{
    public partial class PDForm : Form
    {
        int CurRows = 0, AllRows = 0;
        RecsList[] AllRecs;
        public struct RecsList
        {
            public string series;
            public string number;
            public string registration;
            public string name;
            public string surname;
            public string patronymic;
            public int del;
            public int change;
        }

        private void ReadFromDB()
        {
            int i = 0;
            string filename = File.ReadAllText("path.txt");
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            SQLiteCommand CheckNots = new SQLiteCommand("SELECT series, number, registration, name, surname, patronymic FROM personaldata;", data);
            SQLiteCommand CountRecs = new SQLiteCommand("SELECT COUNT(*) FROM personaldata;", data);
            data.Open();
            AllRows = Convert.ToInt32(CountRecs.ExecuteScalar());
            AllRecs = new RecsList[AllRows];
            SQLiteDataReader NotsReader = CheckNots.ExecuteReader();
            if (NotsReader.HasRows)
            {
                i = 0;
                while (NotsReader.Read())
                {
                    AllRecs[i].series = (NotsReader.GetInt32(0)).ToString();
                    AllRecs[i].number = (NotsReader.GetInt32(1)).ToString();
                    AllRecs[i].registration = NotsReader.GetString(2);
                    AllRecs[i].name = NotsReader.GetString(3);
                    AllRecs[i].surname = NotsReader.GetString(4);
                    AllRecs[i].patronymic = NotsReader.GetString(5);
                    AllRecs[i].del = 0;
                    AllRecs[i].change = 0;
                    i++;
                }
            }
            NotsReader.Close();
            data.Close();
        }

        private void UpdateTable()
        {
            int i = 0;
            this.NotsGrid.Rows.Clear();
            NotsGrid.AllowUserToAddRows = false;
            string filename = File.ReadAllText("path.txt");
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            SQLiteCommand CheckNots = new SQLiteCommand("SELECT series, number, registration, name, surname, patronymic FROM personaldata;", data);
            data.Open();
            SQLiteDataReader NotsReader = CheckNots.ExecuteReader();
            if (NotsReader.HasRows)
            {
                if (CurRows == 0)
                    BackButton.Visible = false;
                i = 0;
                while ((i != 10) && (CurRows != AllRows))
                {
                    NotsGrid.Rows.Add(AllRecs[CurRows].series, AllRecs[CurRows].number, AllRecs[CurRows].registration, AllRecs[CurRows].name, AllRecs[CurRows].surname, AllRecs[CurRows].patronymic, AllRecs[CurRows].del);
                    i++;
                    CurRows++;
                }
            }
            NotsReader.Close();
            NotsGrid.Height = (int)(42 + (22.7 * i));
            data.Close();
            if (CurRows <= 10)
                BackButton.Visible = false;
            else
                BackButton.Visible = true;
            if (CurRows == AllRows)
                NextButton.Visible = false;
            else
                NextButton.Visible = true;
        }

        public PDForm()
        {
            InitializeComponent();
        }

        private void PDForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
        }

        private void NotsGrid_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 6)
                return;
            int CurIndex = 0;
            CurIndex = e.RowIndex + CurRows - NotsGrid.RowCount;
            AllRecs[CurIndex].change = 1;
            switch (e.ColumnIndex)
            {
                case 0:
                    if (Program.CheckInjections(NotsGrid[0, e.RowIndex].Value.ToString().ToLower()) == 1)
                    {
                        MessageBox.Show("Попытка инъекции!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        AllRecs[CurIndex].change = 0;
                        return;
                    }
                    string filename = File.ReadAllText("path.txt");
                    SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
                    data.Open();
                    SQLiteCommand Check = new SQLiteCommand("SELECT series FROM personaldata WHERE series = " + NotsGrid[0, e.RowIndex].Value.ToString() + " AND number=" +
                        "" + NotsGrid[1, e.RowIndex].Value.ToString(), data);
                    if ((CheckPass(NotsGrid[0, e.RowIndex].Value.ToString()) != 1) || (NotsGrid[0, e.RowIndex].Value.ToString().Length != 4))
                    {
                        MessageBox.Show("Проверьте паспортные данные!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    SQLiteDataReader ReaderForCheck = Check.ExecuteReader();
                    if (ReaderForCheck.HasRows)
                    {
                        MessageBox.Show("Нет соответствия по уникальности!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        AllRecs[CurIndex].change = 0;
                        return;
                    }
                    Check = new SQLiteCommand("UPDATE personaldata SET series='" + NotsGrid[0, e.RowIndex].Value.ToString() + "' WHERE series=" + AllRecs[CurIndex].series + " AND " +
                        "number=" + AllRecs[CurIndex].number, data);
                    Check.ExecuteNonQuery();
                    Check = new SQLiteCommand("UPDATE client SET series='" + NotsGrid[0, e.RowIndex].Value.ToString() + "' WHERE series=" + AllRecs[CurIndex].series + " AND " +
                        "number=" + AllRecs[CurIndex].number, data);
                    Check.ExecuteNonQuery();
                    Check = new SQLiteCommand("UPDATE staff SET series='" + NotsGrid[0, e.RowIndex].Value.ToString() + "' WHERE series=" + AllRecs[CurIndex].series + " AND " +
                        "number=" + AllRecs[CurIndex].number, data);
                    Check.ExecuteNonQuery();
                    Check = new SQLiteCommand("UPDATE financials SET series='" + NotsGrid[0, e.RowIndex].Value.ToString() + "' WHERE series=" + AllRecs[CurIndex].series + " AND " +
                        "number=" + AllRecs[CurIndex].number, data);
                    Check.ExecuteNonQuery();
                    AllRecs[CurIndex].series = NotsGrid[0, CurIndex].Value.ToString();
                    data.Close();
                    break;
                case 1:
                    if (Program.CheckInjections(NotsGrid[1, e.RowIndex].Value.ToString().ToLower()) == 1)
                    {
                        MessageBox.Show("Попытка инъекции!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        AllRecs[CurIndex].change = 0;
                        return;
                    }
                    filename = File.ReadAllText("path.txt");
                    data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
                    data.Open();
                    Check = new SQLiteCommand("SELECT series FROM personaldata WHERE series = " + NotsGrid[0, e.RowIndex].Value.ToString() + " AND " +
                        "number=" + NotsGrid[1, e.RowIndex].Value.ToString(), data);
                    if ((CheckPass(NotsGrid[1, e.RowIndex].Value.ToString()) != 1) || (NotsGrid[1, e.RowIndex].Value.ToString().Length != 6))
                    {
                        MessageBox.Show("Проверьте паспортные данные!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    ReaderForCheck = Check.ExecuteReader();
                    if (ReaderForCheck.HasRows)
                    {
                        MessageBox.Show("Нет соответствия по уникальности!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        AllRecs[CurIndex].change = 0;
                        return;
                    }
                    Check = new SQLiteCommand("UPDATE personaldata SET number='" + NotsGrid[1, e.RowIndex].Value.ToString() + "' WHERE series=" + AllRecs[CurIndex].series + " AND " +
                        "number=" + AllRecs[CurIndex].number, data);
                    Check.ExecuteNonQuery();
                    Check = new SQLiteCommand("UPDATE clients SET number='" + NotsGrid[1, e.RowIndex].Value.ToString() + "' WHERE series=" + AllRecs[CurIndex].series + " AND " +
                        "number=" + AllRecs[CurIndex].number, data);
                    Check.ExecuteNonQuery();
                    Check = new SQLiteCommand("UPDATE staff SET number='" + NotsGrid[1, e.RowIndex].Value.ToString() + "' WHERE series=" + AllRecs[CurIndex].series + " AND " +
                        "number=" + AllRecs[CurIndex].number, data);
                    Check.ExecuteNonQuery();
                    Check = new SQLiteCommand("UPDATE financials SET number='" + NotsGrid[1, e.RowIndex].Value.ToString() + "' WHERE series=" + AllRecs[CurIndex].series + " AND " +
                        "number=" + AllRecs[CurIndex].number, data);
                    Check.ExecuteNonQuery();
                    AllRecs[CurIndex].number = NotsGrid[1, CurIndex].Value.ToString();
                    data.Close();
                    break;
                case 2:
                    if (Program.CheckInjections(NotsGrid[2, e.RowIndex].Value.ToString().ToLower()) == 1)
                    {
                        MessageBox.Show("Попытка инъекции!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        AllRecs[CurIndex].change = 0;
                        return;
                    }
                    AllRecs[CurIndex].registration = NotsGrid[2, CurIndex].Value.ToString();
                    break;
                case 3:
                    if (Program.CheckInjections(NotsGrid[3, e.RowIndex].Value.ToString().ToLower()) == 1)
                    {
                        MessageBox.Show("Попытка инъекции!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        AllRecs[CurIndex].change = 0;
                        return;
                    }
                    AllRecs[CurIndex].name = NotsGrid[3, CurIndex].Value.ToString();
                    break;
                case 4:
                    if (Program.CheckInjections(NotsGrid[4, e.RowIndex].Value.ToString().ToLower()) == 1)
                    {
                        MessageBox.Show("Попытка инъекции!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        AllRecs[CurIndex].change = 0;
                        return;
                    }
                    AllRecs[CurIndex].surname = NotsGrid[4, CurIndex].Value.ToString();
                    break;
                case 5:
                    if (Program.CheckInjections(NotsGrid[5, e.RowIndex].Value.ToString().ToLower()) == 1)
                    {
                        MessageBox.Show("Попытка инъекции!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        AllRecs[CurIndex].change = 0;
                        return;
                    }
                    AllRecs[CurIndex].patronymic = NotsGrid[5, CurIndex].Value.ToString();
                    break;
            }
        }

        private int CheckPass(string text)
        {
            for (int i = 0; i < text.Length; i++)
            {
                if ((text[i] < '0') || (text[i] > '9'))
                    return 0;
            }
            return 1;
        }
        private void PDForm_Load(object sender, EventArgs e)
        {
            ReadFromDB();
            UpdateTable();
        }

        private void Info_Click(object sender, EventArgs e)
        {
            Program.Info();
        }

        private void Accept_Click(object sender, EventArgs e)
        {
            AddBool();
            int size = AllRows;
            string filename = File.ReadAllText("path.txt");
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            data.Open();
            SQLiteCommand CheckNots;
            for (int i = 0; i < size; i++)
            {
                if (AllRecs[i].del == 1)
                {
                    CheckNots = new SQLiteCommand("DELETE FROM personaldata WHERE series=" + AllRecs[i].series + " AND number=" + AllRecs[i].number, data);
                    CheckNots.ExecuteNonQuery();
                    CheckNots = new SQLiteCommand("DELETE FROM client WHERE series=" + AllRecs[i].series + " AND number=" + AllRecs[i].number, data);
                    CheckNots.ExecuteNonQuery();
                    CheckNots = new SQLiteCommand("DELETE FROM staff WHERE series=" + AllRecs[i].series + " AND number=" + AllRecs[i].number, data);
                    CheckNots.ExecuteNonQuery();
                    CheckNots = new SQLiteCommand("SELECT id FROM financials WHERE series=" + AllRecs[i].series + " AND number=" + AllRecs[i].number, data);
                    SQLiteDataReader NotsReader = CheckNots.ExecuteReader();
                    if (NotsReader.HasRows)
                    {
                        while (NotsReader.Read())
                        {
                            int j;
                            j = NotsReader.GetInt32(0);
                            SQLiteCommand Casc;
                            Casc = new SQLiteCommand("DELETE FROM service WHERE id=" + j, data);
                            Casc.ExecuteNonQuery();
                        }
                    }
                    NotsReader.Close();

                    CheckNots = new SQLiteCommand("DELETE FROM financials WHERE series=" + AllRecs[i].series + " AND number=" + AllRecs[i].number, data);
                    CheckNots.ExecuteNonQuery();
                }
                if (AllRecs[i].change == 1)
                {
                    CheckNots = new SQLiteCommand("UPDATE personaldata SET name='" + AllRecs[i].name + "', registration='" + AllRecs[i].registration + "', surname='" + AllRecs[i].surname + "', " +
                        "patronymic='" + AllRecs[i].patronymic + "' WHERE series=" + AllRecs[i].series + " AND number=" + AllRecs[i].number, data);
                    CheckNots.ExecuteNonQuery();
                }
            }
            data.Close();
            CurRows = 0;
            ReadFromDB();
            UpdateTable();
        }

        private void Back_Click(object sender, EventArgs e)
        {
            int j = 0;
            int size = NotsGrid.RowCount;
            for (int i = 0; i < size; i++)
            {
                j = CurRows - size + i;
                if (NotsGrid[6, i].Value.ToString() == "True")
                    AllRecs[j].del = 1;
            }
            CurRows = CurRows - 1;
            CurRows = ((int)Math.Floor((double)CurRows / 10) * 10) - 10;
            UpdateTable();
        }

        private void Next_Click(object sender, EventArgs e)
        {
            int j = 0;
            int size = NotsGrid.RowCount;
            for (int i = 0; i < size; i++)
            {
                j = CurRows - 10 + i;
                if (NotsGrid[6, i].Value.ToString() == "True")
                    AllRecs[j].del = 1;
            }
            UpdateTable();
        }

        private void Insert_Click(object sender, EventArgs e)
        {
            if ((Program.CheckInjections(SeriesBox.Text.ToLower()) == 1) || (Program.CheckInjections(NumberBox.Text.ToLower()) == 1) || (Program.CheckInjections(RegistrationBox.Text.ToLower()) == 1) ||
                (Program.CheckInjections(NameBox.Text.ToLower()) == 1) || (Program.CheckInjections(SurnameBox.Text.ToLower()) == 1) || (Program.CheckInjections(PatronymicBox.Text.ToLower()) == 1))
            {
                MessageBox.Show("Попытка инъекции!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string filename = File.ReadAllText("path.txt");
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            data.Open();
            SQLiteCommand AddRecs = new SQLiteCommand("INSERT INTO 'personaldata' ('series', 'number', 'registration', 'name', 'surname', 'patronymic') VALUES (" + SeriesBox.Text + "," +
                " " + NumberBox.Text + ", '" + RegistrationBox.Text + "', '" + NameBox.Text + "', '" + SurnameBox.Text + "', '" + PatronymicBox.Text + "');", data);
            if ((CheckPass(SeriesBox.Text) != 1) || (SeriesBox.Text.Length != 4) || (CheckPass(NumberBox.Text) != 1) || (NumberBox.Text.Length != 6))
            {
                MessageBox.Show("Проверьте паспортные данные!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            SQLiteCommand CheckPersonalData = new SQLiteCommand("SELECT series FROM personaldata WHERE series = " + SeriesBox.Text + " AND number=" + NumberBox.Text, data);
            SQLiteDataReader ReaderForCheck = CheckPersonalData.ExecuteReader();
            if (ReaderForCheck.HasRows)
            {
                MessageBox.Show("Нет соответствия по уникальности!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            AddRecs.ExecuteNonQuery();
            data.Close();
            SeriesBox.Text = "";
            NumberBox.Text = "";
            RegistrationBox.Text = "";
            NameBox.Text = "";
            SurnameBox.Text = "";
            PatronymicBox.Text = "";
            ReadFromDB();
            CurRows = 0;
            UpdateTable();
        }

        private void AddBool()
        {
            int j = 0;
            int size = NotsGrid.RowCount;
            for (int i = 0; i < size; i++)
            {
                j = CurRows - NotsGrid.RowCount + i;
                if (NotsGrid[6, i].Value.ToString() == "True")
                    AllRecs[j].del = 1;
            }
        }
    }
}
