﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Data.SQLite;

namespace op_solopov
{
    public partial class ServiceForm : Form
    {
        int CurRows = 0, AllRows = 0;
        RecsList[] AllRecs;
        public struct RecsList
        {
            public string id;
            public string idservice;
            public string name;
            public int del;
            public int change;
        }

        private void ReadFromDB()
        {
            int i = 0;
            string filename = File.ReadAllText("path.txt");
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            SQLiteCommand CheckNots = new SQLiteCommand("SELECT id, idservice, name FROM service;", data);
            SQLiteCommand CountRecs = new SQLiteCommand("SELECT COUNT(*) FROM service;", data);
            data.Open();
            AllRows = Convert.ToInt32(CountRecs.ExecuteScalar());
            AllRecs = new RecsList[AllRows];
            SQLiteDataReader NotsReader = CheckNots.ExecuteReader();
            if (NotsReader.HasRows)
            {
                i = 0;
                while (NotsReader.Read())
                {
                    AllRecs[i].id = (NotsReader.GetInt32(0)).ToString();
                    AllRecs[i].idservice = (NotsReader.GetInt32(1)).ToString();
                    AllRecs[i].name = NotsReader.GetString(2);
                    AllRecs[i].del = 0;
                    AllRecs[i].change = 0;
                    i++;
                }
            }
            NotsReader.Close();
            data.Close();
        }

        private void UpdateTable()
        {
            int i = 0;
            this.NotsGrid.Rows.Clear();
            NotsGrid.AllowUserToAddRows = false;
            string filename = File.ReadAllText("path.txt");
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            SQLiteCommand CheckNots = new SQLiteCommand("SELECT id, idservice, name FROM service;", data);
            data.Open();
            SQLiteDataReader NotsReader = CheckNots.ExecuteReader();
            if (NotsReader.HasRows)
            {
                if (CurRows == 0)
                    BackButton.Visible = false;
                i = 0;
                while ((i != 10) && (CurRows != AllRows))
                {
                    NotsGrid.Rows.Add(AllRecs[CurRows].id, AllRecs[CurRows].idservice, AllRecs[CurRows].name, AllRecs[CurRows].del);
                    i++;
                    CurRows++;
                }
            }
            NotsReader.Close();
            NotsGrid.Height = (int)(42 + (22.7 * i));
            data.Close();
            if (CurRows <= 10)
                BackButton.Visible = false;
            else
                BackButton.Visible = true;
            if (CurRows == AllRows)
                NextButton.Visible = false;
            else
                NextButton.Visible = true;
        }
        public ServiceForm()
        {
            InitializeComponent();
        }

        private void AddBool()
        {
            int j = 0;
            int size = NotsGrid.RowCount;
            for (int i = 0; i < size; i++)
            {
                j = CurRows - NotsGrid.RowCount + i;
                if (NotsGrid[3, i].Value.ToString() == "True")
                    AllRecs[j].del = 1;
            }
        }

        private void ServiceForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
        }

        private void NotsGrid_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 3)
                return;
            int CurIndex = 0;
            CurIndex = e.RowIndex + CurRows - NotsGrid.RowCount;
            AllRecs[CurIndex].change = 1;
            switch (e.ColumnIndex)
            {
                case 1:
                    if (Program.CheckInjections(NotsGrid[1, e.RowIndex].Value.ToString().ToLower()) == 1)
                    {
                        MessageBox.Show("Попытка инъекции!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        AllRecs[CurIndex].change = 0;
                        return;
                    }
                    string filename = File.ReadAllText("path.txt");
                    SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
                    data.Open();
                    SQLiteCommand CheckService = new SQLiteCommand("SELECT id, idservice FROM service WHERE id = " + NotsGrid[0, e.RowIndex].Value.ToString() + " AND " +
                        "idservice=" + NotsGrid[1, e.RowIndex].Value.ToString(), data);
                    SQLiteDataReader ReaderForCheck = CheckService.ExecuteReader();
                    if (ReaderForCheck.HasRows)
                    {
                        MessageBox.Show("Нет соответствия по уникальности!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        AllRecs[CurIndex].change = 0;
                        return;
                    }
                    SQLiteCommand CheckNots = new SQLiteCommand("UPDATE service SET idservice='" + NotsGrid[1, e.RowIndex].Value.ToString() + "' WHERE id=" + AllRecs[CurIndex].id + " AND " +
                        "idservice=" + AllRecs[CurIndex].idservice, data);
                    AllRecs[CurIndex].idservice = NotsGrid[1, CurIndex].Value.ToString();
                    CheckNots.ExecuteNonQuery();
                    data.Close();
                    break;
                case 2:
                    if (Program.CheckInjections(NotsGrid[2, e.RowIndex].Value.ToString().ToLower()) == 1)
                    {
                        MessageBox.Show("Попытка инъекции!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        AllRecs[CurIndex].change = 0;
                        return;
                    }
                    AllRecs[CurIndex].name = NotsGrid[2, CurIndex].Value.ToString();
                    break;
            }
        }

        private void Info_Click(object sender, EventArgs e)
        {
            Program.Info();
        }

        private void Back_Click(object sender, EventArgs e)
        {
            int j = 0;
            int size = NotsGrid.RowCount;
            for (int i = 0; i < size; i++)
            {
                j = CurRows - size + i;
                if (NotsGrid[3, i].Value.ToString() == "True")
                    AllRecs[j].del = 1;
            }
            CurRows = CurRows - 1;
            CurRows = ((int)Math.Floor((double)CurRows / 10) * 10) - 10;
            UpdateTable();
        }

        private void Accept_Click(object sender, EventArgs e)
        {
            AddBool();
            int size = AllRows;
            string filename = File.ReadAllText("path.txt");
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            data.Open();
            SQLiteCommand CheckNots;
            for (int i = 0; i < size; i++)
            {
                if (AllRecs[i].del == 1)
                {
                    CheckNots = new SQLiteCommand("DELETE FROM service WHERE id=" + AllRecs[i].id + " AND idservice=" + AllRecs[i].idservice, data);
                    CheckNots.ExecuteNonQuery();
                }
                if (AllRecs[i].change == 1)
                {
                    CheckNots = new SQLiteCommand("UPDATE service SET name='" + AllRecs[i].name + "' WHERE id=" + AllRecs[i].id + " AND idservice=" + AllRecs[i].idservice, data);
                    CheckNots.ExecuteNonQuery();
                }
            }
            data.Close();
            CurRows = 0;
            ReadFromDB();
            UpdateTable();
        }

        private void Next_Click(object sender, EventArgs e)
        {
            int j = 0;
            int size = NotsGrid.RowCount;
            for (int i = 0; i < size; i++)
            {
                j = CurRows - 10 + i;
                if (NotsGrid[3, i].Value.ToString() == "True")
                    AllRecs[j].del = 1;
            }
            UpdateTable();
        }

        private void Insert_Click(object sender, EventArgs e)
        {
            if ((Program.CheckInjections(idBox.Text.ToLower()) == 1) || (Program.CheckInjections(idserviceBox.Text.ToLower()) == 1) || (Program.CheckInjections(nameBox.Text.ToLower()) == 1))
            {
                MessageBox.Show("Попытка инъекции!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string filename = File.ReadAllText("path.txt");
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            data.Open();
            SQLiteCommand AddRecs = new SQLiteCommand("INSERT INTO 'service' ('id', 'idservice', 'name') VALUES (" + idBox.Text + ", " + idserviceBox.Text + ", '" + nameBox.Text + "');", data);
            SQLiteCommand CheckPersonalData = new SQLiteCommand("SELECT id, idservice FROM service WHERE id = " + idBox.Text + " AND idservice=" + idserviceBox.Text, data);
            SQLiteDataReader ReaderForCheck = CheckPersonalData.ExecuteReader();
            if (ReaderForCheck.HasRows)
            {
                MessageBox.Show("Нет соответствия по уникальности!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            SQLiteCommand CheckFinancials = new SQLiteCommand("SELECT id FROM financials WHERE id = " + idBox.Text, data);
            ReaderForCheck = CheckFinancials.ExecuteReader();
            if (!ReaderForCheck.HasRows)
            {
                MessageBox.Show("Нет соответствия по таблице финансов!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            AddRecs.ExecuteNonQuery();
            data.Close();
            idBox.Text = "";
            idserviceBox.Text = "";
            nameBox.Text = "";
            ReadFromDB();
            CurRows = 0;
            UpdateTable();
        }

        private void ServiceForm_Load(object sender, EventArgs e)
        {
            ReadFromDB();
            UpdateTable();
        }
    }
}