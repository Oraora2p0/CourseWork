﻿using System;
using System.Windows.Forms;

namespace op_solopov
{
    public partial class Explanation2 : Form
    {
        public Explanation2()
        {
            InitializeComponent();
        }

        private void Prev_Click(object sender, EventArgs e)
        {
            this.Close();
            foreach (Form f in Application.OpenForms)
                if ((f.Name == "Explanation") || (f.Name == "Explanation2"))
                    return;
            new Explanation().Show();
        }
    }
}
