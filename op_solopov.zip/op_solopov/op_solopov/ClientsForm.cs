﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Data.SQLite;

namespace op_solopov
{
    public partial class ClientsForm : Form
    {
        int CurRows = 0, AllRows = 0;
        RecsList[] AllRecs;
        public struct RecsList
        {
            public string series;
            public string number;
            public string band;
            public int del;
            public int change;
        }
        private void ReadFromDB()
        {
            int i = 0;
            string filename = File.ReadAllText("path.txt");
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            SQLiteCommand CheckNots = new SQLiteCommand("SELECT series, number, band FROM client;", data);
            SQLiteCommand CountRecs = new SQLiteCommand("SELECT COUNT(*) FROM client;", data);
            data.Open();
            AllRows = Convert.ToInt32(CountRecs.ExecuteScalar());
            AllRecs = new RecsList[AllRows];
            SQLiteDataReader NotsReader = CheckNots.ExecuteReader();
            if (NotsReader.HasRows)
            {
                i = 0;
                while (NotsReader.Read())
                {
                    AllRecs[i].series = (NotsReader.GetInt32(0)).ToString();
                    AllRecs[i].number = (NotsReader.GetInt32(1)).ToString();
                    AllRecs[i].band= NotsReader.GetString(2);
                    AllRecs[i].del = 0;
                    AllRecs[i].change = 0;
                    i++;
                }
            }
            NotsReader.Close();
            data.Close();
        }

        private void UpdateTable()
        {
            int i = 0;
            this.NotsGrid.Rows.Clear();
            NotsGrid.AllowUserToAddRows = false;
            string filename = File.ReadAllText("path.txt");
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            SQLiteCommand CheckNots = new SQLiteCommand("SELECT series, number, band FROM client;", data);
            data.Open();
            SQLiteDataReader NotsReader = CheckNots.ExecuteReader();
            if (NotsReader.HasRows)
            {
                if (CurRows == 0)
                    BackButton.Visible = false;
                i = 0;
                while ((i != 10) && (CurRows != AllRows))
                {
                    NotsGrid.Rows.Add(AllRecs[CurRows].series, AllRecs[CurRows].number, AllRecs[CurRows].band, AllRecs[CurRows].del);
                    i++;
                    CurRows++;
                }
            }
            NotsReader.Close();
            NotsGrid.Height = (int)(42 + (22.7 * i));
            data.Close();
            if (CurRows <= 10)
                BackButton.Visible = false;
            else
                BackButton.Visible = true;
            if (CurRows == AllRows)
                NextButton.Visible = false;
            else
                NextButton.Visible = true;
        }

        private void AddBool()
        {
            int j = 0;
            int size = NotsGrid.RowCount;
            for (int i = 0; i < size; i++)
            {
                j = CurRows - NotsGrid.RowCount + i;
                if (NotsGrid[3, i].Value.ToString() == "True")
                    AllRecs[j].del = 1;
            }
        }

        private void NotsGrid_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 3)
                return;
            int CurIndex = 0;
            CurIndex = e.RowIndex + CurRows - NotsGrid.RowCount;
            AllRecs[CurIndex].change = 1;
            switch (e.ColumnIndex)
            {
                case 2:
                    if (Program.CheckInjections(NotsGrid[2, e.RowIndex].Value.ToString().ToLower()) == 1)
                    {
                        MessageBox.Show("Попытка инъекции!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        AllRecs[CurIndex].change = 0;
                        return;
                    }
                    AllRecs[CurIndex].band = NotsGrid[2, e.RowIndex].Value.ToString();
                    break;
            }
        }

        private void ClientsForm_Load(object sender, EventArgs e)
        {
            ReadFromDB();
            UpdateTable();
        }

        private void ClientsForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
        }

        private void Info_Click(object sender, EventArgs e)
        {
            Program.Info();
        }

        private void Next_Click(object sender, EventArgs e)
        {
            int j = 0;
            int size = NotsGrid.RowCount;
            for (int i = 0; i < size; i++)
            {
                j = CurRows - 10 + i;
                if (NotsGrid[3, i].Value.ToString() == "True")
                    AllRecs[j].del = 1;
            }
            UpdateTable();
        }

        private void Back_Click(object sender, EventArgs e)
        {
            int j = 0;
            int size = NotsGrid.RowCount;
            for (int i = 0; i < size; i++)
            {
                j = CurRows - size + i;
                if (NotsGrid[3, i].Value.ToString() == "True")
                    AllRecs[j].del = 1;
            }
            CurRows = CurRows - 1;
            CurRows = ((int)Math.Floor((double)CurRows / 10) * 10) - 10;
            UpdateTable();
        }

        private void Accept_Click(object sender, EventArgs e)
        {
            AddBool();
            int size = AllRows;
            string filename = File.ReadAllText("path.txt");
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            data.Open();
            SQLiteCommand CheckNots;
            for (int i = 0; i < size; i++)
            {
                if (AllRecs[i].del == 1)
                {
                    CheckNots = new SQLiteCommand("DELETE FROM client WHERE series=" + AllRecs[i].series + " AND number=" + AllRecs[i].number, data);
                    CheckNots.ExecuteNonQuery();
                }
                if (AllRecs[i].change == 1)
                {
                    CheckNots = new SQLiteCommand("UPDATE client SET band='" + AllRecs[i].band + "' WHERE series=" + AllRecs[i].series + " AND number=" + AllRecs[i].number, data);
                    CheckNots.ExecuteNonQuery();
                }
            }
            data.Close();
            CurRows = 0;
            ReadFromDB();
            UpdateTable();
        }

        private void Insert_Click(object sender, EventArgs e)
        {
            if ((Program.CheckInjections(SeriesBox.Text.ToLower()) == 1) || (Program.CheckInjections(NumberBox.Text.ToLower()) == 1) || (Program.CheckInjections(BandBox.Text.ToLower()) == 1))
            {
                MessageBox.Show("Попытка инъекции!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string filename = File.ReadAllText("path.txt");
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            data.Open();
            SQLiteCommand AddRecs = new SQLiteCommand("INSERT INTO 'client' ('series', 'number', 'band') VALUES (" + SeriesBox.Text + ", " + NumberBox.Text + ", '" + BandBox.Text + "');", data);
            SQLiteCommand CheckPersonalData = new SQLiteCommand("SELECT series, number FROM personaldata WHERE series = " + SeriesBox.Text + " AND number=" + NumberBox.Text, data);
            SQLiteDataReader ReaderForCheck = CheckPersonalData.ExecuteReader();
            if (!ReaderForCheck.HasRows)
            {
                MessageBox.Show("Нет соответствия по ПДн!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            SQLiteCommand CheckUnique = new SQLiteCommand("SELECT series, number FROM client WHERE series = " + SeriesBox.Text + " AND number=" + NumberBox.Text, data);
            ReaderForCheck = CheckUnique.ExecuteReader();
            if (ReaderForCheck.HasRows)
            {
                MessageBox.Show("Не уникальные значения!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            AddRecs.ExecuteNonQuery();
            data.Close();
            SeriesBox.Text = "";
            NumberBox.Text = "";
            BandBox.Text = "";
            ReadFromDB();
            CurRows = 0;
            UpdateTable();
        }

        public ClientsForm()
        {
            InitializeComponent();
        }
    }
}