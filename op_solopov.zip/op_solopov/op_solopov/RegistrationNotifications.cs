﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Data.SQLite;

namespace op_solopov
{
    public partial class RegNots : Form
    {
        int CurRows = 0, AllRows = 0, AdminNum=0;
        RecsList[] AllRecs;
        public RegNots()
        {
            InitializeComponent();
        }

        public struct RecsList
        {
            public string name;
            public string role;
            public int reg;
            public int not;
        }
        private void ReadFromDB()
        {
            int i = 0;
            string filename = File.ReadAllText("path.txt");
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            SQLiteCommand CheckNots = new SQLiteCommand("SELECT username, role, approval FROM users", data);
            SQLiteCommand CountRecs = new SQLiteCommand("SELECT COUNT(id) FROM users", data);
            data.Open();
            AllRows = Convert.ToInt32(CountRecs.ExecuteScalar());
            AllRecs = new RecsList[AllRows];
            SQLiteDataReader NotsReader = CheckNots.ExecuteReader();
            if (NotsReader.HasRows)
            {
                i = 0;
                while (NotsReader.Read())
                {
                    AllRecs[i].name = NotsReader.GetString(0);
                    AllRecs[i].role = NotsReader.GetString(1);
                    AllRecs[i].reg = NotsReader.GetInt32(2);
                    AllRecs[i].not = 0;
                    i++;
                }
            }
            NotsReader.Close();
            CountRecs = new SQLiteCommand("SELECT COUNT(id) FROM users WHERE role='Администратор'", data);
            AdminNum = Convert.ToInt32(CountRecs.ExecuteScalar());
            data.Close();
        }
        private void UpdateTable()
        {
            int i = 0;
            this.NotsGrid.Rows.Clear();
            NotsGrid.AllowUserToAddRows = false;
            string filename = File.ReadAllText("path.txt");
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            SQLiteCommand CheckNots = new SQLiteCommand("SELECT username, role FROM users", data);
            data.Open();
            SQLiteDataReader NotsReader = CheckNots.ExecuteReader();
            if (NotsReader.HasRows)
            {
                if (CurRows == 0)
                    BackButton.Visible = false;
                i = 0;
                while ((i != 10) && (CurRows != AllRows))
                {
                    NotsGrid.Rows.Add(AllRecs[CurRows].name, AllRecs[CurRows].role, AllRecs[CurRows].reg, AllRecs[CurRows].not);
                    i++;
                    CurRows++;
                }
            }
            NotsReader.Close();
            NotsGrid.Height = (int)(35 + (22.5 * i));
            data.Close();
            if (CurRows <= 10)
                BackButton.Visible = false;
            else
                BackButton.Visible = true;
            if (CurRows == AllRows)
                NextButton.Visible = false;
            else
                NextButton.Visible = true;
        }

        private void RegNots_Load(object sender, EventArgs e)
        {
            ReadFromDB();
            UpdateTable();
        }

        private void RegNots_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
        }

        private void AddBool()
        {
            int j = 0;
            int size = NotsGrid.RowCount;
            j = ((int)Math.Floor((double)(CurRows-1) / 10) * 10);
            for (int i = 0; i < size; i++)
            {
                if ((NotsGrid[3, i].Value.ToString() == "True") || (NotsGrid[3, i].Value.ToString() == "1"))
                    AllRecs[j].not = 1;
                else
                    AllRecs[j].not = 0;
                if ((NotsGrid[2, i].Value.ToString() == "True") || (NotsGrid[2, i].Value.ToString() == "1"))
                    AllRecs[j].reg = 1;
                else
                    AllRecs[j].reg = 0;
                j++;
            }
        }

        private void Info_Click(object sender, EventArgs e)
        {
            Program.Info();
        }

        private void Accept_Click(object sender, EventArgs e)
        {
            AddBool();
            int size = AllRows;
            string filename = File.ReadAllText("path.txt");
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            data.Open();
            SQLiteCommand CheckNots;
            for (int i = 0; i < size; i++)
            {
                if (AllRecs[i].not == 1)
                {
                    CheckNots = new SQLiteCommand("DELETE FROM users WHERE username='" + AllRecs[i].name + "'", data);
                    CheckNots.ExecuteNonQuery();
                }
                if (AllRecs[i].reg == 1)
                {
                    CheckNots = new SQLiteCommand("UPDATE users SET approval=" + 1 + " WHERE username='" + AllRecs[i].name + "'", data);
                    CheckNots.ExecuteNonQuery();
                }
                else
                {
                    CheckNots = new SQLiteCommand("UPDATE users SET approval=" + 0 + " WHERE username='" + AllRecs[i].name + "'", data);
                    if ((AdminNum == 1) && (AllRecs[i].role == "Администратор"))
                    {
                        AllRecs[i].reg = 1;
                        MessageBox.Show("Отмена, вы стреляете себе в ногу!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                        CheckNots.ExecuteNonQuery();
                }
            }
            data.Close();
            CurRows = 0;
            ReadFromDB();
            UpdateTable();
        }

        private void Back_Click(object sender, EventArgs e)
        {
            AddBool();
            CurRows = CurRows - 1;
            CurRows = ((int)Math.Floor((double)CurRows / 10) * 10) - 10;
            UpdateTable();
        }

        private void Next_Click(object sender, EventArgs e)
        {
            AddBool();
            UpdateTable();
        }
    }
}