﻿using System;
using System.Windows.Forms;
using System.IO;

namespace op_solopov
{
    static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static public int CheckInjections(string text)
        {
            if ((text.IndexOf("'") != -1) || (text.IndexOf("\"") != -1) || (text.IndexOf("select") != -1) || (text.IndexOf("update") != -1) || (text.IndexOf("delete") != -1) || (text.IndexOf("count") != -1) ||
                (text.IndexOf("insert") != -1) || (text.IndexOf("where") != -1))
                return 1;
            return 0;
        }
        static public void Info()
        {
            foreach (Form f in Application.OpenForms)
                if ((f.Name == "Explanation") || (f.Name == "Explanation2"))
                    return;
            new Explanation().Show();
        }


        static void Main()
        {
            string NameTemp = File.ReadAllText("temp.txt");
            int i = 0;
            string[]  NameTempSplit= NameTemp.Split(new char[] { '?' });
            while ((i < NameTempSplit.Length) && (NameTempSplit[i] != ""))
            {
                System.IO.File.Delete(NameTempSplit[i]);
                i++;
            }
            File.WriteAllText("temp.txt", "");
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Login());
        }
    }
}
