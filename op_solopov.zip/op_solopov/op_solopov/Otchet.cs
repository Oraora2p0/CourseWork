﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Data.SQLite;

namespace op_solopov
{
    public partial class ReportForm : Form
    {
        int CurRows = 0, AllRows = 0, FinalResult=0;
        RecsList[] AllRecs;
        public struct RecsList
        {
            public string id;
            public string series;
            public string number;
            public string seriesapp;
            public string numberapp;
            public string date;
            public string sum;
            public int del;
            public int change;
        }
        private void ReadFromDB()
        {
            int i = 0;
            FinalResult = 0;
            string filename = File.ReadAllText("path.txt"), DateBefore = FirstDate.Text, DateAfter = SecondDate.Text;
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            SQLiteCommand CheckNots = new SQLiteCommand("SELECT id, series, number, seriesapp, numberapp, date, sum FROM financials WHERE date BETWEEN '" + DateBefore + "' AND '"+ DateAfter + "';", data);
            SQLiteCommand CountRecs = new SQLiteCommand("SELECT COUNT(id) FROM financials WHERE date BETWEEN '" + DateBefore + "' AND '" + DateAfter + "';", data);
            data.Open();
            AllRows = Convert.ToInt32(CountRecs.ExecuteScalar());
            AllRecs = new RecsList[AllRows];
            SQLiteDataReader NotsReader = CheckNots.ExecuteReader();
            if (NotsReader.HasRows)
            {
                i = 0;
                while (NotsReader.Read())
                {
                    AllRecs[i].id = (NotsReader.GetInt32(0)).ToString();
                    AllRecs[i].series = (NotsReader.GetInt32(1)).ToString();
                    AllRecs[i].number = (NotsReader.GetInt32(2)).ToString();
                    AllRecs[i].seriesapp = (NotsReader.GetInt32(3)).ToString();
                    AllRecs[i].numberapp = (NotsReader.GetInt32(4)).ToString();
                    AllRecs[i].date = NotsReader.GetString(5);
                    FinalResult = FinalResult + NotsReader.GetInt32(6);
                    AllRecs[i].sum = (NotsReader.GetInt32(6)).ToString();
                    AllRecs[i].del = 0;
                    AllRecs[i].change = 0;
                    i++;
                }
            }
            NotsReader.Close();
            data.Close();
        }
        private void UpdateTable()
        {
            int i = 0;
            this.NotsGrid.Rows.Clear();
            NotsGrid.AllowUserToAddRows = false;
            string filename = File.ReadAllText("path.txt"), DateBefore = FirstDate.Text, DateAfter = SecondDate.Text;
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            SQLiteCommand CheckNots = new SQLiteCommand("SELECT series, number, seriesapp, numberapp, date, sum FROM financials WHERE date BETWEEN '" + DateBefore + "' AND '" + DateAfter + "';", data);
            data.Open();
            SQLiteDataReader NotsReader = CheckNots.ExecuteReader();
            if (NotsReader.HasRows)
            {
                if (CurRows == 0)
                    BackButton.Visible = false;
                i = 0;
                while ((i != 10) && (CurRows != AllRows))
                {
                    NotsGrid.Rows.Add(AllRecs[CurRows].id, AllRecs[CurRows].series, AllRecs[CurRows].number, AllRecs[CurRows].seriesapp, AllRecs[CurRows].numberapp, AllRecs[CurRows].date, AllRecs[CurRows].sum, AllRecs[CurRows].del);
                    i++;
                    CurRows++;
                }
            }
            NotsReader.Close();
            NotsGrid.Height = (int)(42 + (22.7 * i));
            data.Close();
            if (CurRows <= 10)
                BackButton.Visible = false;
            else
                BackButton.Visible = true;
            if (CurRows == AllRows)
                NextButton.Visible = false;
            else
                NextButton.Visible = true;
            ResultLabel.Text = FinalResult.ToString();
        }

        private void ReportForm_Load(object sender, EventArgs e)
        {
            ReadFromDB();
            UpdateTable();
        }

        private int CheckInt(string text)
        {
            if (((text[0] < '0') || (text[0] > '9')) && (text[0] != '-'))
                return 0;
            for (int i = 1; i < text.Length; i++)
            {
                if ((text[i] < '0') || (text[i] > '9'))
                    return 0;
            }
            return 1;
        }
        private int CheckDate(string text)
        {
            int i, j=0;
            char[] year = new char[4];
            char[] month = new char[2];
            char[] day = new char[2];
            if (text.Length !=10)
                return 0;
            for (i = 0; i < 4; i++)
            {
                if ((text[i] < '0') || (text[i] > '9'))
                    return 0;
                year[i] = text[i];
            }
            if (text[i] != '.')
                return 0;
            for (i = 5; i < 7; i++)
            {
                if ((text[i] < '0') || (text[i] > '9'))
                    return 0;
                month[j] = text[i];
                j++;
            }
            if (text[i] != '.')
                return 0;
            j = 0;
            for (i = 8; i < 10; i++)
            {
                if ((text[i] < '0') || (text[i] > '9'))
                    return 0;
                day[j] = text[i];
                j++;
            }
            string y = new string(year), m = new string(month), d = new string(day);
            if ((Convert.ToInt32(y) < 1970) || (Convert.ToInt32(y) > 2021))
                return 0;
            if ((Convert.ToInt32(m) < 1) || (Convert.ToInt32(m) > 12))
                return 0;
            if ((Convert.ToInt32(d) < 1) || (Convert.ToInt32(d) > 31))
                return 0;
            if (((Convert.ToInt32(d) == 29) && (Convert.ToInt32(m) == 2) && (Convert.ToInt32(y) % 4 != 0)) || ((Convert.ToInt32(d) == 28) && (Convert.ToInt32(m) == 2) && (Convert.ToInt32(y) % 4 == 0)))
                return 0;
            if ((Convert.ToInt32(d) == 31) && (Convert.ToInt32(m)!=1 && Convert.ToInt32(m)!=3 && Convert.ToInt32(m)!=5 && Convert.ToInt32(m)!=7 && Convert.ToInt32(m)!=8 && Convert.ToInt32(m)!=10 && Convert.ToInt32(m)!=12))
                return 0;
            if ((Convert.ToInt32(d) == 30) && (Convert.ToInt32(m) != 4 && Convert.ToInt32(m) != 6 && Convert.ToInt32(m) != 9 && Convert.ToInt32(m) != 11))
                return 0;
            return 1;
        }

        private void AddBool()
        {
            int j = 0;
            int size = NotsGrid.RowCount;
            for (int i = 0; i < size; i++)
            {
                j = CurRows - NotsGrid.RowCount + i;
                if (NotsGrid[7, i].Value.ToString() == "True")
                    AllRecs[j].del = 1;
            }
        }

        private void ReportForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
        }

        private void NotsGrid_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 7)
                return;
            int CurIndex = 0;
            CurIndex = e.RowIndex + CurRows - NotsGrid.RowCount;
            AllRecs[CurIndex].change = 1;
            switch (e.ColumnIndex)
            {
                case 5:
                    if (Program.CheckInjections(NotsGrid[5, e.RowIndex].Value.ToString().ToLower()) == 1)
                    {
                        MessageBox.Show("Попытка инъекции!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        AllRecs[CurIndex].change = 0;
                        return;
                    }
                    if (CheckDate(NotsGrid[5, CurIndex].Value.ToString()) != 1)
                    {
                        MessageBox.Show("Некоректная дата!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        AllRecs[CurIndex].change = 0;
                        return;
                    }
                    AllRecs[CurIndex].date = NotsGrid[5, e.RowIndex].Value.ToString();
                    break;
                case 6:
                    if (Program.CheckInjections(NotsGrid[6, e.RowIndex].Value.ToString().ToLower()) == 1)
                    {
                        MessageBox.Show("Попытка инъекции!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        AllRecs[CurIndex].change = 0;
                        return;
                    }
                    if (CheckInt(NotsGrid[6, CurIndex].Value.ToString()) != 1)
                    {
                        MessageBox.Show("Некоректная сумма!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        AllRecs[CurIndex].change = 0;
                        return;
                    }
                    AllRecs[CurIndex].sum = NotsGrid[6, e.RowIndex].Value.ToString();
                    break;
            }
        }

        private void Info_Click(object sender, EventArgs e)
        {
            Program.Info();
        }

        private void Back_Click(object sender, EventArgs e)
        {
            int j = 0;
            int size = NotsGrid.RowCount;
            for (int i = 0; i < size; i++)
            {
                j = CurRows - size + i;
                if (NotsGrid[7, i].Value.ToString() == "True")
                    AllRecs[j].del = 1;
            }

            CurRows = CurRows - 1;
            CurRows = ((int)Math.Floor((double)CurRows / 10) * 10) - 10;
            UpdateTable();
        }

        private void Accept_Click(object sender, EventArgs e)
        {
            if ((CheckDate(FirstDate.Text) != 1) || (CheckDate(SecondDate.Text) != 1) || (String.Compare(FirstDate.Text, SecondDate.Text) >= 0))
            {
                MessageBox.Show("Некоректные даты для расчёта!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            AddBool();
            int size = AllRows;
            string filename = File.ReadAllText("path.txt");
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            data.Open();
            SQLiteCommand CheckNots;
            for (int i = 0; i < size; i++)
            {
                if (AllRecs[i].del == 1)
                {
                    CheckNots = new SQLiteCommand("DELETE FROM financials WHERE id='" + AllRecs[i].id + "'", data);
                    CheckNots.ExecuteNonQuery();
                }
                if (AllRecs[i].change == 1)
                {
                    CheckNots = new SQLiteCommand("UPDATE financials SET series=" + AllRecs[i].series + ", number=" + AllRecs[i].number + ", seriesapp=" + AllRecs[i].seriesapp + ", " +
                        "numberapp=" + AllRecs[i].numberapp + ", date='" + AllRecs[i].date + "', sum=" + AllRecs[i].sum + " WHERE id='" + AllRecs[i].id + "'", data);
                    CheckNots.ExecuteNonQuery();
                }
            }
            data.Close();
            CurRows = 0;
            ReadFromDB();
            UpdateTable();
        }

        private void Insert_Click(object sender, EventArgs e)
        {
            if ((Program.CheckInjections(SeriesBox.Text.ToLower()) == 1) || (Program.CheckInjections(NumberBox.Text.ToLower()) == 1) || (Program.CheckInjections(SeriesappBox.Text.ToLower()) == 1) ||
                (Program.CheckInjections(NumberappBox.Text.ToLower()) == 1) || (Program.CheckInjections(DateBox.Text.ToLower()) == 1) || (Program.CheckInjections(SumBox.Text.ToLower()) == 1))
            {
                MessageBox.Show("Попытка инъекции!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string filename = File.ReadAllText("path.txt");
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            data.Open();
            SQLiteCommand AddRecs = new SQLiteCommand("INSERT INTO 'financials' ('series', 'number', 'seriesapp', 'numberapp', 'date', 'sum') VALUES (" + SeriesBox.Text + ", " + NumberBox.Text + "" +
                ", " + SeriesappBox.Text + ", " + NumberappBox.Text + ", '" + DateBox.Text + "', " + SumBox.Text + ");", data);
            SQLiteCommand CheckPersonalData = new SQLiteCommand("SELECT series, number FROM personaldata WHERE series = " + SeriesBox.Text + " AND number=" + NumberBox.Text, data);
            SQLiteDataReader ReaderForCheck = CheckPersonalData.ExecuteReader();
            if (!ReaderForCheck.HasRows)
            {
                MessageBox.Show("Нет соответствия по ПДн!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            SQLiteCommand CheckStaff = new SQLiteCommand("SELECT series, number FROM staff WHERE series = " + SeriesappBox.Text + " AND number=" + NumberappBox.Text, data);
            ReaderForCheck = CheckStaff.ExecuteReader();
            if (!ReaderForCheck.HasRows)
            {
                MessageBox.Show("Нет соответствия по сотрудникам!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (CheckDate(DateBox.Text) != 1)
            {
                MessageBox.Show("Некорректная дата!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (CheckInt(SumBox.Text) != 1)
            {
                MessageBox.Show("Некорректная сумма!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            AddRecs.ExecuteNonQuery();
            data.Close();
            ReadFromDB();
            SeriesBox.Text = "";
            NumberBox.Text = "";
            SeriesappBox.Text = "";
            NumberappBox.Text = "";
            DateBox.Text = "";
            SumBox.Text = "";
            CurRows = 0;
            UpdateTable();
        }

        private void MakeChart_Click(object sender, EventArgs e)
        {
            foreach (var series in Chart.Series)
                series.Points.Clear();
            DateTime minDate = new DateTime(1970, 01, 01);
            DateTime maxDate = DateTime.Now;
            Chart.ChartAreas[0].AxisX.Minimum = minDate.ToOADate();
            Chart.ChartAreas[0].AxisX.Maximum = maxDate.ToOADate();
            minDate = new DateTime(1970, 01, 01);
            Chart.Series[1].Points.AddXY(minDate, 0);
            Chart.Series[1].Points.AddXY(maxDate, 0);
            DateTime[] CopyDate = new DateTime[AllRows];
            int[] CopySum = new int[AllRows];
            for (int i = 0; i < AllRows; i++)
            {
                CopySum[i] = Convert.ToInt32(AllRecs[i].sum);
                CopyDate[i] = DateTime.Parse(AllRecs[i].date.Replace(".", "-"));
            }
            DateTime valdate;
            int valint;
            for (int i = 0; i < AllRows; i++)
            {
                for (int j = 0; j < AllRows; j++)
                {
                    if (CopyDate[i] < CopyDate[j])
                    {
                        valdate = CopyDate[i];
                        CopyDate[i] = CopyDate[j];
                        CopyDate[j] = valdate;
                        valint = CopySum[i];
                        CopySum[i] = CopySum[j];
                        CopySum[j] = valint;
                    }
                }
            }
            Chart.Series[0].Points.AddXY(new DateTime(1970, 1, 1), 0);
            valint = 0;
            for (int i = 0; i < AllRows; i++)
            {
                minDate = new DateTime(2016, 06, 04);
                valint = valint + CopySum[i];
                Chart.Series[0].Points.AddXY(CopyDate[i], valint);
            }
        }

        private void Next_Click(object sender, EventArgs e)
        {
            int j = 0;
            int size = NotsGrid.RowCount;
            for (int i = 0; i < size; i++)
            {
                j = CurRows - 10 + i;
                if (NotsGrid[7, i].Value.ToString() == "True")
                    AllRecs[j].del = 1;
            }
            UpdateTable();
        }

        public ReportForm()
        {
            InitializeComponent();
        }
    }
}
