﻿namespace op_solopov
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.label5 = new System.Windows.Forms.Label();
            this.NameLabel = new System.Windows.Forms.Label();
            this.Notifications = new System.Windows.Forms.Button();
            this.ReportButton = new System.Windows.Forms.Button();
            this.StaffButton = new System.Windows.Forms.Button();
            this.ServiceButton = new System.Windows.Forms.Button();
            this.ClientsButton = new System.Windows.Forms.Button();
            this.PDButton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SaveAll = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(709, 120);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 20);
            this.label5.TabIndex = 9;
            // 
            // NameLabel
            // 
            this.NameLabel.BackColor = System.Drawing.Color.Transparent;
            this.NameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NameLabel.Location = new System.Drawing.Point(266, 12);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(579, 20);
            this.NameLabel.TabIndex = 10;
            this.NameLabel.Text = "Здесь будет текст";
            this.NameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Notifications
            // 
            this.Notifications.BackColor = System.Drawing.Color.Black;
            this.Notifications.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.Notifications.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Notifications.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Notifications.ForeColor = System.Drawing.Color.Red;
            this.Notifications.Location = new System.Drawing.Point(459, 184);
            this.Notifications.Name = "Notifications";
            this.Notifications.Size = new System.Drawing.Size(197, 29);
            this.Notifications.TabIndex = 2;
            this.Notifications.Text = "Управление";
            this.Notifications.UseVisualStyleBackColor = false;
            this.Notifications.Click += new System.EventHandler(this.Notifications_Click);
            // 
            // ReportButton
            // 
            this.ReportButton.BackColor = System.Drawing.Color.Black;
            this.ReportButton.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.ReportButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ReportButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ReportButton.ForeColor = System.Drawing.Color.Red;
            this.ReportButton.Location = new System.Drawing.Point(459, 271);
            this.ReportButton.Name = "ReportButton";
            this.ReportButton.Size = new System.Drawing.Size(197, 29);
            this.ReportButton.TabIndex = 3;
            this.ReportButton.Text = "Вывод отчёта";
            this.ReportButton.UseVisualStyleBackColor = false;
            this.ReportButton.Click += new System.EventHandler(this.ReportButton_Click);
            // 
            // StaffButton
            // 
            this.StaffButton.BackColor = System.Drawing.Color.Black;
            this.StaffButton.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.StaffButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StaffButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StaffButton.ForeColor = System.Drawing.Color.Red;
            this.StaffButton.Location = new System.Drawing.Point(242, 365);
            this.StaffButton.Name = "StaffButton";
            this.StaffButton.Size = new System.Drawing.Size(197, 29);
            this.StaffButton.TabIndex = 4;
            this.StaffButton.Text = "Персонал";
            this.StaffButton.UseVisualStyleBackColor = false;
            this.StaffButton.Click += new System.EventHandler(this.StaffButton_Click);
            // 
            // ServiceButton
            // 
            this.ServiceButton.BackColor = System.Drawing.Color.Black;
            this.ServiceButton.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.ServiceButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ServiceButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ServiceButton.ForeColor = System.Drawing.Color.Red;
            this.ServiceButton.Location = new System.Drawing.Point(459, 120);
            this.ServiceButton.Name = "ServiceButton";
            this.ServiceButton.Size = new System.Drawing.Size(197, 29);
            this.ServiceButton.TabIndex = 1;
            this.ServiceButton.Text = "Услуги";
            this.ServiceButton.UseVisualStyleBackColor = false;
            this.ServiceButton.Click += new System.EventHandler(this.ServiceButton_Click);
            // 
            // ClientsButton
            // 
            this.ClientsButton.BackColor = System.Drawing.Color.Black;
            this.ClientsButton.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.ClientsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ClientsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ClientsButton.ForeColor = System.Drawing.Color.Red;
            this.ClientsButton.Location = new System.Drawing.Point(681, 365);
            this.ClientsButton.Name = "ClientsButton";
            this.ClientsButton.Size = new System.Drawing.Size(197, 29);
            this.ClientsButton.TabIndex = 6;
            this.ClientsButton.Text = "Клиенты";
            this.ClientsButton.UseVisualStyleBackColor = false;
            this.ClientsButton.Click += new System.EventHandler(this.ClientsButton_Click);
            // 
            // PDButton
            // 
            this.PDButton.BackColor = System.Drawing.Color.Black;
            this.PDButton.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.PDButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PDButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PDButton.ForeColor = System.Drawing.Color.Red;
            this.PDButton.Location = new System.Drawing.Point(459, 365);
            this.PDButton.Name = "PDButton";
            this.PDButton.Size = new System.Drawing.Size(197, 29);
            this.PDButton.TabIndex = 5;
            this.PDButton.Text = "ПДн";
            this.PDButton.UseVisualStyleBackColor = false;
            this.PDButton.Click += new System.EventHandler(this.PDButton_Click);
            // 
            // button1
            // 
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(45, 45);
            this.button1.TabIndex = 23;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // SaveAll
            // 
            this.SaveAll.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("SaveAll.BackgroundImage")));
            this.SaveAll.Location = new System.Drawing.Point(1104, 12);
            this.SaveAll.Name = "SaveAll";
            this.SaveAll.Size = new System.Drawing.Size(40, 43);
            this.SaveAll.TabIndex = 11;
            this.SaveAll.UseVisualStyleBackColor = true;
            this.SaveAll.Click += new System.EventHandler(this.SaveAll_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Black;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.ForeColor = System.Drawing.Color.Red;
            this.button2.Location = new System.Drawing.Point(12, 480);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(197, 29);
            this.button2.TabIndex = 7;
            this.button2.Text = "Назад";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Firebrick;
            this.BackgroundImage = global::op_solopov.Properties.Resources._31;
            this.ClientSize = new System.Drawing.Size(1156, 521);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.PDButton);
            this.Controls.Add(this.ClientsButton);
            this.Controls.Add(this.ServiceButton);
            this.Controls.Add(this.StaffButton);
            this.Controls.Add(this.ReportButton);
            this.Controls.Add(this.Notifications);
            this.Controls.Add(this.SaveAll);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.label5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Главное меню";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Main_FormClosed);
            this.Load += new System.EventHandler(this.Main_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Button SaveAll;
        private System.Windows.Forms.Button Notifications;
        private System.Windows.Forms.Button ReportButton;
        private System.Windows.Forms.Button StaffButton;
        private System.Windows.Forms.Button ServiceButton;
        private System.Windows.Forms.Button ClientsButton;
        private System.Windows.Forms.Button PDButton;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}