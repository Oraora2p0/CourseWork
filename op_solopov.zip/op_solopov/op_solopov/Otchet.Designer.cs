﻿namespace op_solopov
{
    partial class ReportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReportForm));
            this.Chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.NotsGrid = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.series = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.number = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.seriesapp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numberapp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.del = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.FirstDate = new System.Windows.Forms.TextBox();
            this.SecondDate = new System.Windows.Forms.TextBox();
            this.SeriesBox = new System.Windows.Forms.TextBox();
            this.NumberBox = new System.Windows.Forms.TextBox();
            this.SeriesappBox = new System.Windows.Forms.TextBox();
            this.NumberappBox = new System.Windows.Forms.TextBox();
            this.DateBox = new System.Windows.Forms.TextBox();
            this.SumBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.BackButton = new System.Windows.Forms.Button();
            this.Apply = new System.Windows.Forms.Button();
            this.NextButton = new System.Windows.Forms.Button();
            this.MakeChart = new System.Windows.Forms.Button();
            this.InsertButton = new System.Windows.Forms.Button();
            this.ResultLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Chart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NotsGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // Chart
            // 
            this.Chart.BackColor = System.Drawing.Color.Silver;
            this.Chart.BorderSkin.PageColor = System.Drawing.Color.DarkRed;
            chartArea2.AxisX.IntervalAutoMode = System.Windows.Forms.DataVisualization.Charting.IntervalAutoMode.VariableCount;
            chartArea2.Name = "ChartArea1";
            this.Chart.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.Chart.Legends.Add(legend2);
            this.Chart.Location = new System.Drawing.Point(12, 82);
            this.Chart.Name = "Chart";
            series3.BorderWidth = 3;
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series3.Color = System.Drawing.Color.Red;
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            series3.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Date;
            series4.BorderWidth = 3;
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series4.Color = System.Drawing.Color.Purple;
            series4.Legend = "Legend1";
            series4.Name = "Series2";
            this.Chart.Series.Add(series3);
            this.Chart.Series.Add(series4);
            this.Chart.Size = new System.Drawing.Size(602, 300);
            this.Chart.TabIndex = 10;
            this.Chart.Text = "chart1";
            // 
            // NotsGrid
            // 
            this.NotsGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.NotsGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.series,
            this.number,
            this.seriesapp,
            this.numberapp,
            this.date,
            this.sum,
            this.del});
            this.NotsGrid.Location = new System.Drawing.Point(641, 110);
            this.NotsGrid.Name = "NotsGrid";
            this.NotsGrid.Size = new System.Drawing.Size(844, 34);
            this.NotsGrid.TabIndex = 12;
            this.NotsGrid.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.NotsGrid_CellEndEdit);
            // 
            // id
            // 
            this.id.HeaderText = "id операции";
            this.id.Name = "id";
            this.id.ReadOnly = true;
            // 
            // series
            // 
            this.series.HeaderText = "Серия паспорта исполнителя";
            this.series.MaxInputLength = 4;
            this.series.Name = "series";
            this.series.ReadOnly = true;
            this.series.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // number
            // 
            this.number.HeaderText = "Номер паспорта исполнителя";
            this.number.MaxInputLength = 6;
            this.number.Name = "number";
            this.number.ReadOnly = true;
            this.number.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // seriesapp
            // 
            this.seriesapp.HeaderText = "Серия паспорта заверителя";
            this.seriesapp.MaxInputLength = 4;
            this.seriesapp.Name = "seriesapp";
            this.seriesapp.ReadOnly = true;
            this.seriesapp.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // numberapp
            // 
            this.numberapp.HeaderText = "Номер паспорта заверителя";
            this.numberapp.MaxInputLength = 6;
            this.numberapp.Name = "numberapp";
            this.numberapp.ReadOnly = true;
            this.numberapp.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // date
            // 
            this.date.HeaderText = "Дата операции";
            this.date.MaxInputLength = 10;
            this.date.Name = "date";
            this.date.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // sum
            // 
            this.sum.HeaderText = "Сумма";
            this.sum.MaxInputLength = 9;
            this.sum.Name = "sum";
            this.sum.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // del
            // 
            this.del.HeaderText = "Удалить запись";
            this.del.Name = "del";
            // 
            // FirstDate
            // 
            this.FirstDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FirstDate.Location = new System.Drawing.Point(829, 80);
            this.FirstDate.MaxLength = 12;
            this.FirstDate.Name = "FirstDate";
            this.FirstDate.Size = new System.Drawing.Size(88, 22);
            this.FirstDate.TabIndex = 15;
            this.FirstDate.Text = "1970.01.01";
            // 
            // SecondDate
            // 
            this.SecondDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SecondDate.Location = new System.Drawing.Point(1195, 81);
            this.SecondDate.MaxLength = 12;
            this.SecondDate.Name = "SecondDate";
            this.SecondDate.Size = new System.Drawing.Size(88, 22);
            this.SecondDate.TabIndex = 16;
            this.SecondDate.Text = "2021.06.07";
            // 
            // SeriesBox
            // 
            this.SeriesBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SeriesBox.Location = new System.Drawing.Point(641, 404);
            this.SeriesBox.MaxLength = 4;
            this.SeriesBox.Name = "SeriesBox";
            this.SeriesBox.Size = new System.Drawing.Size(211, 24);
            this.SeriesBox.TabIndex = 17;
            // 
            // NumberBox
            // 
            this.NumberBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumberBox.Location = new System.Drawing.Point(938, 404);
            this.NumberBox.MaxLength = 6;
            this.NumberBox.Name = "NumberBox";
            this.NumberBox.Size = new System.Drawing.Size(228, 24);
            this.NumberBox.TabIndex = 18;
            // 
            // SeriesappBox
            // 
            this.SeriesappBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SeriesappBox.Location = new System.Drawing.Point(1245, 404);
            this.SeriesappBox.MaxLength = 4;
            this.SeriesappBox.Name = "SeriesappBox";
            this.SeriesappBox.Size = new System.Drawing.Size(214, 24);
            this.SeriesappBox.TabIndex = 19;
            // 
            // NumberappBox
            // 
            this.NumberappBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumberappBox.Location = new System.Drawing.Point(641, 476);
            this.NumberappBox.MaxLength = 6;
            this.NumberappBox.Name = "NumberappBox";
            this.NumberappBox.Size = new System.Drawing.Size(211, 24);
            this.NumberappBox.TabIndex = 20;
            // 
            // DateBox
            // 
            this.DateBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DateBox.Location = new System.Drawing.Point(938, 476);
            this.DateBox.MaxLength = 10;
            this.DateBox.Name = "DateBox";
            this.DateBox.Size = new System.Drawing.Size(214, 24);
            this.DateBox.TabIndex = 21;
            // 
            // SumBox
            // 
            this.SumBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SumBox.Location = new System.Drawing.Point(1245, 476);
            this.SumBox.MaxLength = 9;
            this.SumBox.Name = "SumBox";
            this.SumBox.Size = new System.Drawing.Size(228, 24);
            this.SumBox.TabIndex = 22;
            // 
            // button1
            // 
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(45, 45);
            this.button1.TabIndex = 27;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Info_Click);
            // 
            // BackButton
            // 
            this.BackButton.BackColor = System.Drawing.Color.Black;
            this.BackButton.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.BackButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BackButton.ForeColor = System.Drawing.Color.Red;
            this.BackButton.Location = new System.Drawing.Point(641, 74);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(135, 28);
            this.BackButton.TabIndex = 28;
            this.BackButton.Text = "Назад";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.Back_Click);
            // 
            // Apply
            // 
            this.Apply.BackColor = System.Drawing.Color.Black;
            this.Apply.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.Apply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Apply.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Apply.ForeColor = System.Drawing.Color.Red;
            this.Apply.Location = new System.Drawing.Point(995, 74);
            this.Apply.Name = "Apply";
            this.Apply.Size = new System.Drawing.Size(135, 28);
            this.Apply.TabIndex = 29;
            this.Apply.Text = "Принять";
            this.Apply.UseVisualStyleBackColor = false;
            this.Apply.Click += new System.EventHandler(this.Accept_Click);
            // 
            // NextButton
            // 
            this.NextButton.BackColor = System.Drawing.Color.Black;
            this.NextButton.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.NextButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NextButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NextButton.ForeColor = System.Drawing.Color.Red;
            this.NextButton.Location = new System.Drawing.Point(1350, 76);
            this.NextButton.Name = "NextButton";
            this.NextButton.Size = new System.Drawing.Size(135, 28);
            this.NextButton.TabIndex = 30;
            this.NextButton.Text = "Далее";
            this.NextButton.UseVisualStyleBackColor = false;
            this.NextButton.Click += new System.EventHandler(this.Next_Click);
            // 
            // MakeChart
            // 
            this.MakeChart.BackColor = System.Drawing.Color.Black;
            this.MakeChart.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.MakeChart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MakeChart.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MakeChart.ForeColor = System.Drawing.Color.Red;
            this.MakeChart.Location = new System.Drawing.Point(169, 398);
            this.MakeChart.Name = "MakeChart";
            this.MakeChart.Size = new System.Drawing.Size(286, 28);
            this.MakeChart.TabIndex = 31;
            this.MakeChart.Text = "Построить график";
            this.MakeChart.UseVisualStyleBackColor = false;
            this.MakeChart.Click += new System.EventHandler(this.MakeChart_Click);
            // 
            // InsertButton
            // 
            this.InsertButton.BackColor = System.Drawing.Color.Black;
            this.InsertButton.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.InsertButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InsertButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InsertButton.ForeColor = System.Drawing.Color.Red;
            this.InsertButton.Location = new System.Drawing.Point(916, 543);
            this.InsertButton.Name = "InsertButton";
            this.InsertButton.Size = new System.Drawing.Size(286, 28);
            this.InsertButton.TabIndex = 32;
            this.InsertButton.Text = "Вставить";
            this.InsertButton.UseVisualStyleBackColor = false;
            this.InsertButton.Click += new System.EventHandler(this.Insert_Click);
            // 
            // ResultLabel
            // 
            this.ResultLabel.BackColor = System.Drawing.Color.Transparent;
            this.ResultLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ResultLabel.Location = new System.Drawing.Point(1061, 23);
            this.ResultLabel.Name = "ResultLabel";
            this.ResultLabel.Size = new System.Drawing.Size(266, 22);
            this.ResultLabel.TabIndex = 33;
            this.ResultLabel.Text = "Здесь конечный результат";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(912, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 22);
            this.label1.TabIndex = 34;
            this.label1.Text = "Итог подсчёта:";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(934, 451);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(162, 22);
            this.label2.TabIndex = 35;
            this.label2.Text = "Дата";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(637, 379);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(199, 22);
            this.label3.TabIndex = 36;
            this.label3.Text = "Серия исполнителя";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(934, 379);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(218, 22);
            this.label4.TabIndex = 37;
            this.label4.Text = "Номер исполнителя";
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(637, 451);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(199, 22);
            this.label5.TabIndex = 38;
            this.label5.Text = "Номер заверителя";
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(1241, 373);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(199, 22);
            this.label6.TabIndex = 39;
            this.label6.Text = "Серия заверителя";
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(1241, 451);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(162, 22);
            this.label7.TabIndex = 40;
            this.label7.Text = "Сумма";
            // 
            // ReportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::op_solopov.Properties.Resources.truesoviet;
            this.ClientSize = new System.Drawing.Size(1509, 676);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ResultLabel);
            this.Controls.Add(this.InsertButton);
            this.Controls.Add(this.MakeChart);
            this.Controls.Add(this.NextButton);
            this.Controls.Add(this.Apply);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.SumBox);
            this.Controls.Add(this.DateBox);
            this.Controls.Add(this.NumberappBox);
            this.Controls.Add(this.SeriesappBox);
            this.Controls.Add(this.NumberBox);
            this.Controls.Add(this.SeriesBox);
            this.Controls.Add(this.SecondDate);
            this.Controls.Add(this.FirstDate);
            this.Controls.Add(this.NotsGrid);
            this.Controls.Add(this.Chart);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ReportForm";
            this.Text = "Формирование отчёта";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ReportForm_FormClosed);
            this.Load += new System.EventHandler(this.ReportForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Chart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NotsGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart Chart;
        private System.Windows.Forms.DataGridView NotsGrid;
        private System.Windows.Forms.TextBox FirstDate;
        private System.Windows.Forms.TextBox SecondDate;
        private System.Windows.Forms.TextBox SeriesBox;
        private System.Windows.Forms.TextBox NumberBox;
        private System.Windows.Forms.TextBox SeriesappBox;
        private System.Windows.Forms.TextBox NumberappBox;
        private System.Windows.Forms.TextBox DateBox;
        private System.Windows.Forms.TextBox SumBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button Apply;
        private System.Windows.Forms.Button NextButton;
        private System.Windows.Forms.Button MakeChart;
        private System.Windows.Forms.Button InsertButton;
        private System.Windows.Forms.Label ResultLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn series;
        private System.Windows.Forms.DataGridViewTextBoxColumn number;
        private System.Windows.Forms.DataGridViewTextBoxColumn seriesapp;
        private System.Windows.Forms.DataGridViewTextBoxColumn numberapp;
        private System.Windows.Forms.DataGridViewTextBoxColumn date;
        private System.Windows.Forms.DataGridViewTextBoxColumn sum;
        private System.Windows.Forms.DataGridViewCheckBoxColumn del;
    }
}