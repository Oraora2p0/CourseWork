﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Data.SQLite;
using System.Security.Cryptography;
using System.IO;

namespace op_solopov
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        private void RegisterBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Login().Show();
        }

        private void Register_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void ButtonRegister_Click(object sender, EventArgs e)
        {
            if ((Program.CheckInjections(RegisterPasswordConf.Text.ToLower()) == 1) || (Program.CheckInjections(RegisterUsername.Text.ToLower()) == 1) || (Program.CheckInjections(RegisterPassword.Text.ToLower()) == 1))
            {
                MessageBox.Show("Попытка инъекции!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            bool[] CheckPolicy=new bool[5];
            for (int i = 0; i < 5; i++)
                CheckPolicy[i] = false;
            char symbol;
            if (RegisterPassword.Text == "" || RegisterPasswordConf.Text == "" || RegisterUsername.Text == "" || RoleBox.SelectedItem.ToString() == "")
            {
                MessageBox.Show("Не все поля заполнены!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (RegisterPassword.Text.Length >= 8)
            {
                CheckPolicy[0] = true;
                for (int i = 0; i < RegisterPassword.Text.Length; i++)
                {
                    symbol = RegisterPassword.Text[i];
                    if (((symbol >= 'а') && (symbol <= 'я')) || ((symbol >= 'a') && (symbol <= 'z')))
                        CheckPolicy[1] = true;
                    else
                    {
                        if (((symbol >= 'А') && (symbol <= 'Я')) || ((symbol >= 'A') && (symbol <= 'Z')))
                            CheckPolicy[2] = true;
                        else
                        {
                            if ((symbol >= '0') && (symbol <= '9'))
                                CheckPolicy[3] = true;
                            else
                            {
                                if (((symbol >= 33) && (symbol <= 47)) || ((symbol >= 58) && (symbol <= 64)) || ((symbol >= 91) && (symbol <= 96)) || ((symbol >= 123) && (symbol <= 126)))
                                    CheckPolicy[4] = true;
                            }
                        }
                    }
                }
            }
            for (int i = 0; i < 5; i++)
                if (CheckPolicy[i] == false)
                {
                    MessageBox.Show("Введите более надёжный пароль!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            if (RegisterPassword.Text == RegisterPasswordConf.Text)
            {
                bool ok = false, approval=false;
                string filename = File.ReadAllText("path.txt");
                SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
                MD5 md5 = new MD5CryptoServiceProvider();
                string hash = BitConverter.ToString(md5.ComputeHash(Encoding.UTF8.GetBytes((RegisterUsername.Text + RegisterPassword.Text)))).Replace("-", String.Empty);
                string UserRole = RoleBox.SelectedItem.ToString();
                SQLiteCommand CheckName = new SQLiteCommand("SELECT id FROM users WHERE username = '" + RegisterUsername.Text + "'", data);
                SQLiteCommand CheckAll = new SQLiteCommand("SELECT id FROM users WHERE role='Администратор'", data);
                data.Open();
                SQLiteDataReader ReaderName = CheckName.ExecuteReader();
                SQLiteDataReader ReaderAll = CheckAll.ExecuteReader();
                if (!ReaderName.HasRows)
                {
                    SQLiteCommand addUser;
                    if (!ReaderAll.HasRows)
                    {
                        addUser = new SQLiteCommand("INSERT INTO 'users' ('username', 'hash', 'role', 'approval') VALUES ('" + RegisterUsername.Text + "','" + hash + "','" + UserRole + "','" + 1 + "');", data);
                        approval = true;
                    }
                    else
                        addUser = new SQLiteCommand("INSERT INTO 'users' ('username', 'hash', 'role', 'approval') VALUES ('" + RegisterUsername.Text + "','" + hash + "','" + UserRole + "','" + 0 + "');", data);
                    addUser.ExecuteNonQuery();
                    ok = true;
                }
                data.Close();
                if (ok)
                {
                    this.Hide();
                    new Login().Show();
                    if (approval == true)
                        MessageBox.Show("Теперь вы коммунист!", "Информация!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show("Пока вы не коммунист, обратитесь к администратору.", "Информация!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    RegisterUsername.Text = "";
                    RegisterPassword.Text = "";
                    RegisterPasswordConf.Text = "";
                    return;
                }
                else
                {
                    MessageBox.Show("Такой товарищ существует!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            else
            {
                MessageBox.Show("Пароли не совпадают!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                RegisterPassword.Text = "";
                RegisterPasswordConf.Text = "";
            }
        }

        private void Info_Click(object sender, EventArgs e)
        {
            Program.Info();
        }
    }
}