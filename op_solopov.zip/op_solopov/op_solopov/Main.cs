﻿using System;
using System.Windows.Forms;
using System.Data.SQLite;
using System.IO;

namespace op_solopov
{
    public partial class Main : Form
    {
        ClientsForm ClientF;
        ServiceForm ServiceF;
        ReportForm ReportF;
        RegNots NotF;
        StaffForm StaffF;
        PDForm PDF;
        Explanation EF;

        int userid;
        string UserRole;
        public Main(int id, string role)
        {
            InitializeComponent();
            this.userid = id;
            this.UserRole = role;
        }

        private void Main_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            string filename = File.ReadAllText("path.txt");
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            SQLiteCommand find = new SQLiteCommand("SELECT username FROM users WHERE id = '" + userid + "';", data);
            data.Open();
            SQLiteDataReader ReadToFind = find.ExecuteReader();
            if (ReadToFind.Read())
                NameLabel.Text="Здравствуйте, товарищ "+(Convert.ToString(ReadToFind["username"]))+"!";
            ReadToFind.Close();
            if (UserRole != "Администратор")
            {
                Notifications.Visible = false;
                if (UserRole == "Бухгалтер")
                {
                    ServiceButton.Visible = false;
                    ClientsButton.Visible = false;
                    PDButton.Visible = false;
                    StaffButton.Visible = false;
                }
                else
                {
                    ServiceButton.Visible = false;
                    ReportButton.Visible = false;
                }
            }
        }

        private void SaveAll_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.DefaultExt = ".db";
            sfd.Filter = "db files (*.db)|*.db";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string LastName = File.ReadAllText("path.txt");
                File.Copy(LastName, sfd.FileName);
                File.WriteAllText("path.txt", sfd.FileName);
                System.IO.File.AppendAllText("temp.txt", LastName + '?');
            }
        }
        private void Notifications_Click(object sender, EventArgs e)
        {
            foreach (Form f in Application.OpenForms)
                if (f.Name == "RegNots")
                    return;
            NotF = new RegNots();
            NotF.Show();
        }

        private void ReportButton_Click(object sender, EventArgs e)
        {
            foreach (Form f in Application.OpenForms)
                if (f.Name == "ReportForm")
                    return;
            ReportF = new ReportForm();
            ReportF.Show();
        }

        private void StaffButton_Click(object sender, EventArgs e)
        {
            foreach (Form f in Application.OpenForms)
                if (f.Name == "ClientsForm")
                    return;
            StaffF = new StaffForm();
            StaffF.Show();
        }

        private void ServiceButton_Click(object sender, EventArgs e)
        {
            foreach (Form f in Application.OpenForms)
                if (f.Name == "ServiceForm")
                    return;
            ServiceF = new ServiceForm();
            ServiceF.Show();
        }

        private void ClientsButton_Click(object sender, EventArgs e)
        {
            foreach (Form f in Application.OpenForms)
                if (f.Name == "ClientsForm")
                    return;
            ClientF = new ClientsForm();
            ClientF.Show();
        }

        private void PDButton_Click(object sender, EventArgs e)
        {
            foreach (Form f in Application.OpenForms)
                if (f.Name == "PDForm")
                    return;
            PDF = new PDForm();
            PDF.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (Form f in Application.OpenForms)
                if ((f.Name == "Explanation") || (f.Name == "Explanation2"))
                    return;
            EF = new Explanation();
            EF.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new Login().Show();
            this.Hide();
            if (ClientF != null)
                ClientF.Close();
            if (ServiceF != null)
                ServiceF.Close();
            if (ReportF != null)
                ReportF.Close();
            if (NotF != null)
                NotF.Close();
            if (StaffF != null)
                StaffF.Close();
            if (PDF != null)
                PDF.Close();
            if (EF != null)
                EF.Close();
        }
    }
}