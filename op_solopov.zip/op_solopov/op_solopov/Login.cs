﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Data.SQLite;
using System.Security.Cryptography;
using System.IO;

namespace op_solopov
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void LoginGotoregistration_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Register().Show();
        }

        private void Login_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void LoginSignin_Click(object sender, EventArgs e)
        {
            if ((Program.CheckInjections(LoginUsername.Text.ToLower()) == 1) || (Program.CheckInjections(LoginPassword.Text.ToLower()) == 1))
            {
                MessageBox.Show("Попытка инъекции!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int id = 0, AppFlag = 0;
            string role ="СОЛОПОВ НИКИТА, 7281";
            string filename = File.ReadAllText("path.txt");
            SQLiteConnection data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
            MD5 md5 = new MD5CryptoServiceProvider();
            string hash = BitConverter.ToString(md5.ComputeHash(Encoding.UTF8.GetBytes((LoginUsername.Text + LoginPassword.Text)))).Replace("-", String.Empty);
            SQLiteCommand checkUser = new SQLiteCommand("SELECT id, hash, approval, role FROM users WHERE username = '" + LoginUsername.Text + "'", data);
            data.Open();
            SQLiteDataReader reader = checkUser.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                if (reader.GetString(1) == hash)
                {
                    id = reader.GetInt32(0);
                    AppFlag = reader.GetInt32(2);
                    role = reader.GetString(3);
                }
                reader.Close();
            }
            data.Close();
            if (id == 0)
                MessageBox.Show("Некоректные данные для входа!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                if (AppFlag == 0)
                    MessageBox.Show("Ваша учётная запись не подтверждена администратором!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                {
                    this.Hide();
                    new Main(id, role).Show();
                }
            }
            LoginUsername.Text = "";
            LoginPassword.Text = "";
        }
        private void Login_Load(object sender, EventArgs e)
        {
            string filename = File.ReadAllText("path.txt");
            SQLiteConnection data;
            if (!File.Exists(filename))
            {
                SQLiteConnection.CreateFile(filename);
                data = new SQLiteConnection(@"Data Source=" + filename + "; Version=3;");
                data.Open();
                SQLiteCommand CreateTable = new SQLiteCommand("PRAGMA foreign_keys=on; CREATE TABLE IF NOT EXISTS 'users' ( 'id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 'username' TEXT NOT " +
                    "NULL, 'role' TEXT NOT NULL, 'hash' TEXT NOT NULL, 'approval' INTEGER NOT NULL);", data);
                CreateTable.ExecuteNonQuery();
                CreateTable = new SQLiteCommand("CREATE TABLE IF NOT EXISTS 'personaldata' ('series' INTEGER, 'number' INTEGER, 'registration' TEXT, 'name' TEXT, 'surname' TEXT, 'patronymic' " +
                    "TEXT, PRIMARY KEY('series', 'number'));", data);
                CreateTable.ExecuteNonQuery();
                CreateTable = new SQLiteCommand("CREATE TABLE IF NOT EXISTS 'client' ('band'  TEXT, 'series' INTEGER, 'number' INTEGER, PRIMARY KEY('series', 'number'), FOREIGN KEY('series', 'number') " +
                    "REFERENCES 'personaldata'('series', 'number') ON DELETE CASCADE ON UPDATE CASCADE);", data);
                CreateTable.ExecuteNonQuery();
                CreateTable = new SQLiteCommand("CREATE TABLE IF NOT EXISTS 'staff' ('series' INTEGER, 'number' INTEGER, 'post' TEXT, FOREIGN KEY('number', 'series') REFERENCES 'personaldata'('number', 'series') " +
                    "ON DELETE CASCADE ON UPDATE CASCADE, PRIMARY KEY('series', 'number'));", data);
                CreateTable.ExecuteNonQuery();
                CreateTable = new SQLiteCommand("CREATE TABLE 'financials' ('id' INTEGER, 'series' INTEGER, 'number' INTEGER, 'seriesapp' INTEGER, 'numberapp' INTEGER, 'date' TEXT, 'sum' " +
                    "INTEGER, FOREIGN KEY('series', 'number') REFERENCES 'personaldata'('series', 'number') ON DELETE CASCADE ON UPDATE CASCADE, FOREIGN KEY('seriesapp', 'numberapp') " +
                    "REFERENCES 'staff'('series', 'number') ON DELETE CASCADE ON UPDATE CASCADE, PRIMARY KEY('id' AUTOINCREMENT));", data);
                CreateTable.ExecuteNonQuery();
                CreateTable = new SQLiteCommand("CREATE TABLE IF NOT EXISTS 'service' ('id' INTEGER, 'idservice' INTEGER, 'name' INTEGER, PRIMARY KEY('id', 'idservice'), FOREIGN KEY('id') " +
                    "REFERENCES 'financials'('id') ON UPDATE CASCADE ON DELETE CASCADE);", data);
                CreateTable.ExecuteNonQuery();
                //Данные
                SQLiteCommand AddRecs = new SQLiteCommand("INSERT INTO 'personaldata' ('series', 'number', 'registration', 'name', 'surname', 'patronymic') VALUES " +
                    "(3815, 500654, 'г. Санкт-Петербург, ул. Харченко, 45', 'Ксения', 'Трофимова', 'Марковна'), (2270, 319160, 'г. Томск, ул. Пушкина, 11', 'Агата', 'Рыжова', 'Викторовна'), " +
                    "(4058, 789232, 'г. Санкт-Петербург, ул. Парголовская, 43', 'Александра', 'Шестакова', 'Егоровна'), (4489, 225255, 'г. Улан-Удэ, ул. Бабушкина, 15', 'Арина', 'Балашова', 'Данииловна'), " +
                    "(4770, 113337, 'г. Санкт-Петербург, ул. Миллионная, 5', 'Виктория', 'Михайлова', 'Руслановна'), (5002, 508118, 'г. Томск, ул. Партизанская, 8', 'Юлия', 'Позднякова', 'Давидовна'), " +
                    "(5367, 781117, 'г. Томск, ул. Лыткина, 18', 'Ульяна', 'Новикова', 'Руслановна'), (6011, 678231, 'г. Томск, ул. Ленина, 63', 'Мария', 'Лаптева', 'Викторовна'), " +
                    "(7819, 307607, 'г. Улан-Удэ, ул. Ермаковская, 37', 'Степан', 'Трофимов', 'Андреевич'), (9810, 724316, 'г. Улан-Удэ, ул. Воровского, 28', 'Федор', 'Соболев', 'Максимович');", data);
                AddRecs.ExecuteNonQuery();
                AddRecs = new SQLiteCommand("INSERT INTO 'client' ('series', 'number', 'band') VALUES (3815, 500654, 'Что не так с этим названием?'), (5367, 781117, '73% ада'), " +
                    "(6011, 678231, 'Кричащие голоса уничтоженных счастьем'), (7819, 307607, 'Крышеснос'), (9810, 724316, 'Мозговынос');", data);
                AddRecs.ExecuteNonQuery();
                AddRecs = new SQLiteCommand("INSERT INTO 'staff' ('series', 'number', 'post') VALUES (2270, 319160, 'Менеджер по уборке территории'), (4058, 789232, 'Бухгалтер'), " +
                    "(4489, 225255, 'Директор компании'), (4770, 113337, 'HR-менеджер'), (5002, 508118, 'Заместитель директора');", data);
                AddRecs.ExecuteNonQuery();
                AddRecs = new SQLiteCommand("INSERT INTO 'financials' ('id', 'series', 'number', 'seriesapp', 'numberapp', 'date', 'sum') VALUES (1, 3815, 500654, 4489, 225255, '2009.01.08', -255000), " +
                    "(2, 5367, 781117, 5002, 508118, '1995.08.18', -80000), (3, 6011, 678231, 4489, 225255, '2012.10.09', 80000), (4, 7819, 307607, 5002, 508118, '1999.09.20', 30000), " +
                    "(5, 9810, 724316, 5002, 508118, '2012.05.02', 230000);", data);
                AddRecs.ExecuteNonQuery();
                AddRecs = new SQLiteCommand("INSERT INTO 'service' ('id', 'idservice', 'name') VALUES (1, 1, 'Реклама по радио'), (1, 2, 'Реклама по телевидению'), (1, 3, 'Реклама в социальных сетях'), " +
                    "(2, 2, 'Реклама по телевидению'), (2, 3, 'Реклама в социальных сетях'), (2, 4, 'Продажа альбома'), (2, 5, 'Загрузка треков на цифровые площадки'), (3, 6, 'Создание сайта'), " +
                    "(3, 7, 'Организация концерта'), (3, 8, 'Продажа записей'), (4, 4, 'Продажа альбома'), (4, 5, 'Загрузка треков на цифровые площадки'), (4, 9, 'Запись альбома'), (4, 10, 'Запись видеоклипа'), " +
                    "(5, 6, 'Создание сайта'), (5, 7, 'Организация концерта'), (5, 11, 'Организация интервью');", data);
                AddRecs.ExecuteNonQuery();
                data.Close();
            }
        }

        private void Info_Click(object sender, EventArgs e)
        {
            Program.Info();
        }
    }
}
