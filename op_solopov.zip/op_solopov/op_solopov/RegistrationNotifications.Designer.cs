﻿namespace op_solopov
{
    partial class RegNots
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegNots));
            this.NotsGrid = new System.Windows.Forms.DataGridView();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.role = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AppReg = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.DelNot = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.NextButton = new System.Windows.Forms.Button();
            this.Apply = new System.Windows.Forms.Button();
            this.BackButton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.NotsGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // NotsGrid
            // 
            this.NotsGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.NotsGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.name,
            this.role,
            this.AppReg,
            this.DelNot});
            this.NotsGrid.Location = new System.Drawing.Point(12, 103);
            this.NotsGrid.Name = "NotsGrid";
            this.NotsGrid.Size = new System.Drawing.Size(444, 102);
            this.NotsGrid.TabIndex = 7;
            // 
            // name
            // 
            this.name.HeaderText = "Имя";
            this.name.Name = "name";
            this.name.ReadOnly = true;
            // 
            // role
            // 
            this.role.HeaderText = "Роль";
            this.role.Name = "role";
            this.role.ReadOnly = true;
            // 
            // AppReg
            // 
            this.AppReg.HeaderText = "Разрешить регистрацию";
            this.AppReg.Name = "AppReg";
            // 
            // DelNot
            // 
            this.DelNot.HeaderText = "Убрать уведомление";
            this.DelNot.Name = "DelNot";
            // 
            // NextButton
            // 
            this.NextButton.BackColor = System.Drawing.Color.Black;
            this.NextButton.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.NextButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NextButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NextButton.ForeColor = System.Drawing.Color.Red;
            this.NextButton.Location = new System.Drawing.Point(321, 69);
            this.NextButton.Name = "NextButton";
            this.NextButton.Size = new System.Drawing.Size(135, 28);
            this.NextButton.TabIndex = 65;
            this.NextButton.Text = "Далее";
            this.NextButton.UseVisualStyleBackColor = false;
            this.NextButton.Click += new System.EventHandler(this.Next_Click);
            // 
            // Apply
            // 
            this.Apply.BackColor = System.Drawing.Color.Black;
            this.Apply.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.Apply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Apply.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Apply.ForeColor = System.Drawing.Color.Red;
            this.Apply.Location = new System.Drawing.Point(168, 69);
            this.Apply.Name = "Apply";
            this.Apply.Size = new System.Drawing.Size(135, 28);
            this.Apply.TabIndex = 64;
            this.Apply.Text = "Принять";
            this.Apply.UseVisualStyleBackColor = false;
            this.Apply.Click += new System.EventHandler(this.Accept_Click);
            // 
            // BackButton
            // 
            this.BackButton.BackColor = System.Drawing.Color.Black;
            this.BackButton.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.BackButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BackButton.ForeColor = System.Drawing.Color.Red;
            this.BackButton.Location = new System.Drawing.Point(12, 69);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(135, 28);
            this.BackButton.TabIndex = 63;
            this.BackButton.Text = "Назад";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.Back_Click);
            // 
            // button1
            // 
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(45, 45);
            this.button1.TabIndex = 60;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Info_Click);
            // 
            // RegNots
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::op_solopov.Properties.Resources._2;
            this.ClientSize = new System.Drawing.Size(471, 463);
            this.Controls.Add(this.NextButton);
            this.Controls.Add(this.Apply);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.NotsGrid);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RegNots";
            this.Text = "Управление";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.RegNots_FormClosed);
            this.Load += new System.EventHandler(this.RegNots_Load);
            ((System.ComponentModel.ISupportInitialize)(this.NotsGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataGridView NotsGrid;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button NextButton;
        private System.Windows.Forms.Button Apply;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn role;
        private System.Windows.Forms.DataGridViewCheckBoxColumn AppReg;
        private System.Windows.Forms.DataGridViewCheckBoxColumn DelNot;
    }
}